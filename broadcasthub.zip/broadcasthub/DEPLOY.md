# 🚀 BroadcastHub — Deploy to Vercel in 10 Minutes

## What You're Building
- Admin broadcasts to groups → members get **email notifications**
- Members can **message admin privately** → admin gets email
- Admin can **reply** → member gets email
- Real-time updates via Firebase

---

## Step 1 — Firebase Setup (5 min)

1. Go to **https://console.firebase.google.com**
2. Click **"Add project"** → name it `broadcasthub` → Create
3. From the dashboard, click **"Web"** icon (`</>`) → register app → copy the config values
4. Go to **Build → Authentication → Get Started → Email/Password → Enable**
5. Go to **Build → Firestore Database → Create database → Start in test mode**
6. Go to **Project Settings → Service Accounts → Generate new private key** → download JSON
   - You'll need: `client_email` and `private_key` from this file

---

## Step 2 — Resend Setup (2 min)

1. Go to **https://resend.com** → Sign up (free)
2. Go to **API Keys → Create API Key** → copy it
3. For testing, use `from: onboarding@resend.dev` (works without domain setup)
4. Optional: verify your own domain for a custom from-address

---

## Step 3 — Deploy to Vercel (3 min)

### Option A: GitHub (Recommended)
1. Push this folder to a GitHub repo
2. Go to **https://vercel.com** → New Project → Import your repo
3. Add all environment variables (see below)
4. Click **Deploy**

### Option B: Vercel CLI
```bash
npm i -g vercel
cd broadcasthub
vercel
```

---

## Environment Variables to Add in Vercel

Go to **Vercel Dashboard → Your Project → Settings → Environment Variables** and add:

| Variable | Value |
|---|---|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | From Firebase config |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | From Firebase config |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | From Firebase config |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | From Firebase config |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | From Firebase config |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | From Firebase config |
| `NEXT_PUBLIC_ADMIN_EMAIL` | The email you'll use as admin |
| `RESEND_API_KEY` | From Resend dashboard |
| `RESEND_FROM_EMAIL` | `onboarding@resend.dev` (or your domain) |
| `FIREBASE_CLIENT_EMAIL` | From downloaded service account JSON |
| `FIREBASE_PRIVATE_KEY` | From downloaded service account JSON |

---

## Step 4 — First Login

1. Go to your Vercel URL (e.g. `https://broadcasthub-xyz.vercel.app`)
2. Register with the **exact email** you set as `NEXT_PUBLIC_ADMIN_EMAIL` → you become Admin
3. Share the URL with members → they register → appear in Members list

---

## Firestore Security Rules (Paste in Firebase Console → Firestore → Rules)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
      allow read: if request.auth != null && 
        request.auth.token.email == "YOUR_ADMIN_EMAIL";
      
      match /inbox/{msgId} {
        allow read, write: if request.auth.uid == userId;
      }
    }
    match /broadcasts/{id} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        request.auth.token.email == "YOUR_ADMIN_EMAIL";
    }
    match /userMessages/{id} {
      allow create: if request.auth != null;
      allow read, write: if request.auth != null && 
        (resource.data.fromUid == request.auth.uid || 
         request.auth.token.email == "YOUR_ADMIN_EMAIL");
    }
  }
}
```

Replace `YOUR_ADMIN_EMAIL` with your actual admin email.

---

## You're Live! 🎉

Share the URL and start broadcasting. All email notifications go out automatically.
