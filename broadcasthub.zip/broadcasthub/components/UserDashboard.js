import { useState, useEffect } from 'react';
import { useAuth } from '../lib/auth';
import { db } from '../lib/firebase';
import { collection, addDoc, onSnapshot, query, orderBy, doc, updateDoc } from 'firebase/firestore';

const s = {
  layout: { display:'flex', height:'100vh', overflow:'hidden', background:'var(--bg)' },
  sidebar: { width:'240px', background:'var(--surface)', borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', flexShrink:0 },
  main: { flex:1, display:'flex', flexDirection:'column', overflow:'hidden' },
  logo: { padding:'18px 16px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:'10px' },
  logoIcon: { width:'36px', height:'36px', background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', borderRadius:'10px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px' },
  navSection: { padding:'10px 8px' },
  navItem: { display:'flex', alignItems:'center', gap:'10px', padding:'9px 10px', borderRadius:'8px', cursor:'pointer', fontSize:'13px', fontWeight:'500', color:'var(--text2)', transition:'all 0.2s' },
  badge: { marginLeft:'auto', background:'var(--accent)', color:'white', fontSize:'10px', fontWeight:'600', padding:'2px 7px', borderRadius:'20px', fontFamily:'var(--mono)' },
  topbar: { padding:'14px 22px', borderBottom:'1px solid var(--border)', background:'var(--surface)', display:'flex', alignItems:'center', gap:'10px' },
  dot: { width:'8px', height:'8px', borderRadius:'50%', background:'var(--success)', boxShadow:'0 0 6px var(--success)' },
  msgList: { flex:1, overflowY:'auto', padding:'16px 22px', display:'flex', flexDirection:'column', gap:'10px' },
  msgCard: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--radius)', padding:'14px 16px', cursor:'pointer', transition:'all 0.2s' },
  sectionHead: { padding:'12px 22px 8px', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)', textTransform:'uppercase', letterSpacing:'1px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'space-between' },
  avatar: { width:'30px', height:'30px', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'12px', fontWeight:'700', flexShrink:0 },
  replyBox: { padding:'14px 22px', borderTop:'1px solid var(--border)', background:'var(--surface)', display:'flex', gap:'10px', alignItems:'flex-end' },
  replyInput: { flex:1, background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:'8px', color:'var(--text)', fontFamily:'var(--font)', fontSize:'13px', padding:'10px 14px', resize:'none', outline:'none', minHeight:'42px' },
  iconBtn: { width:'38px', height:'38px', borderRadius:'8px', background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', border:'none', color:'white', fontSize:'15px', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 },
  bubble: { maxWidth:'75%', padding:'10px 14px', borderRadius:'14px', fontSize:'13px', lineHeight:'1.6' },
  threadWrap: { flex:1, overflowY:'auto', padding:'16px 22px', display:'flex', flexDirection:'column', gap:'10px' },
};

export default function UserDashboard() {
  const { profile, logout } = useAuth();
  const [activePanel, setActivePanel] = useState('inbox');
  const [inbox, setInbox] = useState([]);
  const [openMsg, setOpenMsg] = useState(null);
  const [msgText, setMsgText] = useState('');
  const [sending, setSending] = useState(false);
  const [toast, setToast] = useState(null);
  const [myMessages, setMyMessages] = useState([]);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(null), 4000); };

  // Listen to user inbox (sub-collection under their user doc)
  useEffect(() => {
    if (!profile?.uid) return;
    const q = query(collection(db, 'users', profile.uid, 'inbox'), orderBy('sentAt', 'desc'));
    const unsub = onSnapshot(q, snap => setInbox(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
    return unsub;
  }, [profile]);

  // Listen to own messages sent to admin
  useEffect(() => {
    if (!profile?.uid) return;
    const q = query(collection(db, 'userMessages'), orderBy('sentAt', 'desc'));
    const unsub = onSnapshot(q, snap => {
      setMyMessages(snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(m => m.fromUid === profile.uid));
    });
    return unsub;
  }, [profile]);

  const openInboxMsg = async (msg) => {
    if (!msg.read) {
      await updateDoc(doc(db, 'users', profile.uid, 'inbox', msg.id), { read: true });
    }
    setOpenMsg(msg);
    setActivePanel('thread');
  };

  const sendToAdmin = async () => {
    if (!msgText.trim()) return;
    setSending(true);
    try {
      await addDoc(collection(db, 'userMessages'), {
        fromUid: profile.uid,
        fromName: profile.name || profile.email,
        fromEmail: profile.email,
        message: msgText,
        sentAt: new Date().toISOString(),
        readByAdmin: false,
        replies: [],
      });
      // Notify admin by email
      await fetch('/api/notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'user_to_admin', message: msgText, fromName: profile.name || profile.email, fromEmail: profile.email }),
      });
      showToast('✉️ Message sent to admin!');
      setMsgText('');
    } catch (e) {
      showToast('❌ Failed: ' + e.message);
    }
    setSending(false);
  };

  const unread = inbox.filter(m => !m.read).length;
  const navItems = [
    { id: 'inbox', icon: '📥', label: 'Inbox', badge: unread },
    { id: 'contact', icon: '✉️', label: 'Message Admin' },
    { id: 'my-messages', icon: '📤', label: 'My Messages' },
  ];
  const panelTitle = { inbox: 'My Inbox', contact: 'Message Admin', 'my-messages': 'My Messages', thread: 'Message' };

  return (
    <div style={s.layout}>
      {/* Sidebar */}
      <div style={s.sidebar}>
        <div style={s.logo}>
          <div style={s.logoIcon}>📡</div>
          <div>
            <div style={{ fontSize:'14px', fontWeight:'700' }}>BroadcastHub</div>
            <div style={{ fontSize:'10px', color:'var(--text3)', fontFamily:'var(--mono)' }}>Member Portal</div>
          </div>
        </div>
        <div style={s.navSection}>
          {navItems.map(n => (
            <div key={n.id} style={{ ...s.navItem, ...(activePanel===n.id||activePanel==='thread'&&n.id==='inbox'?{background:'var(--surface3)',color:'var(--accent)'}:{}) }}
              onClick={() => { setActivePanel(n.id); setOpenMsg(null); }}>
              <span>{n.icon}</span> {n.label}
              {n.badge > 0 && <span style={s.badge}>{n.badge}</span>}
            </div>
          ))}
        </div>
        <div style={{ marginTop:'auto', padding:'14px 12px', borderTop:'1px solid var(--border)' }}>
          <div style={{ fontSize:'12px', color:'var(--text2)', marginBottom:'2px' }}>Signed in as</div>
          <div style={{ fontSize:'13px', fontWeight:'500', marginBottom:'10px', wordBreak:'break-all' }}>{profile.name || profile.email}</div>
          <button onClick={logout} style={{ width:'100%', padding:'8px', borderRadius:'8px', background:'var(--surface2)', border:'1px solid var(--border)', color:'var(--text2)', fontSize:'12px', cursor:'pointer' }}>Sign Out</button>
        </div>
      </div>

      {/* Main */}
      <div style={s.main}>
        <div style={s.topbar}>
          <div style={s.dot} />
          <div style={{ fontSize:'15px', fontWeight:'600' }}>{panelTitle[activePanel]}</div>
          <div style={{ marginLeft:'auto', fontSize:'11px', color:'var(--success)', fontFamily:'var(--mono)' }}>📧 Email alerts ON</div>
        </div>

        {/* Inbox */}
        {activePanel === 'inbox' && (
          <>
            <div style={s.sectionHead}><span>Messages from Admin</span><span>{unread} unread</span></div>
            <div style={s.msgList}>
              {inbox.map(m => (
                <div key={m.id} style={{ ...s.msgCard, ...(m.read?{}:{borderLeft:'3px solid var(--accent)'}) }} onClick={() => openInboxMsg(m)}>
                  {!m.read && <div style={{ width:'8px', height:'8px', borderRadius:'50%', background:'var(--accent)', boxShadow:'0 0 6px var(--accent)', float:'right', marginTop:'2px' }} />}
                  <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'8px' }}>
                    <div style={{ ...s.avatar, background:'linear-gradient(135deg,#4f8ef7,#7c3aed)' }}>A</div>
                    <div>
                      <div style={{ fontSize:'13px', fontWeight:'600' }}>Admin</div>
                      <div style={{ fontSize:'11px', color:'var(--text3)' }}>Broadcast</div>
                    </div>
                    <div style={{ marginLeft:'auto', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{new Date(m.sentAt).toLocaleString()}</div>
                  </div>
                  <div style={{ fontSize:'13px', color:'var(--text2)', lineHeight:'1.6' }}>{m.message.substring(0,100)}{m.message.length>100?'...':''}</div>
                </div>
              ))}
              {inbox.length === 0 && <div style={{ textAlign:'center', color:'var(--text3)', padding:'40px', fontSize:'13px' }}>Your inbox is empty. You'll get emails when admin sends a broadcast.</div>}
            </div>
          </>
        )}

        {/* Thread view */}
        {activePanel === 'thread' && openMsg && (
          <>
            <div style={{ ...s.sectionHead, cursor:'pointer' }} onClick={() => { setActivePanel('inbox'); setOpenMsg(null); }}>← Back to Inbox</div>
            <div style={{ padding:'10px 22px', background:'rgba(16,185,129,0.06)', borderBottom:'1px solid rgba(16,185,129,0.15)', fontSize:'12px', color:'var(--success)', display:'flex', alignItems:'center', gap:'6px', fontFamily:'var(--mono)' }}>
              📧 You received an email notification for this message
            </div>
            <div style={s.threadWrap}>
              <div style={{ display:'flex', justifyContent:'flex-start' }}>
                <div style={{ ...s.bubble, background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', color:'white' }}>
                  {openMsg.message}
                  <div style={{ fontSize:'10px', opacity:0.7, marginTop:'4px', fontFamily:'var(--mono)' }}>{new Date(openMsg.sentAt).toLocaleString()}</div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Contact Admin */}
        {activePanel === 'contact' && (
          <>
            <div style={{ padding:'14px 22px', background:'var(--surface2)', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:'12px' }}>
              <div style={{ ...s.avatar, background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', width:'40px', height:'40px', fontSize:'16px' }}>A</div>
              <div>
                <div style={{ fontSize:'14px', fontWeight:'600' }}>Admin</div>
                <div style={{ fontSize:'12px', color:'var(--success)', display:'flex', alignItems:'center', gap:'4px' }}>● Online</div>
              </div>
              <div style={{ marginLeft:'auto', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>Admin receives email on your message</div>
            </div>
            <div style={{ ...s.threadWrap, justifyContent: myMessages.length===0?'center':'flex-start', alignItems: myMessages.length===0?'center':'stretch' }}>
              {myMessages.length === 0 && <div style={{ color:'var(--text3)', fontSize:'13px', textAlign:'center' }}>Start a conversation with admin. Your message will be private.</div>}
              {myMessages.map(m => (
                <div key={m.id} style={{ display:'flex', flexDirection:'column', gap:'8px' }}>
                  <div style={{ display:'flex', justifyContent:'flex-end' }}>
                    <div style={{ ...s.bubble, background:'var(--surface3)', border:'1px solid var(--border)' }}>
                      {m.message}
                      <div style={{ fontSize:'10px', color:'var(--text3)', marginTop:'4px', fontFamily:'var(--mono)' }}>{new Date(m.sentAt).toLocaleString()}</div>
                    </div>
                  </div>
                  {m.replies?.map((r, i) => (
                    <div key={i} style={{ display:'flex', justifyContent: r.from==='admin'?'flex-start':'flex-end' }}>
                      <div style={{ ...s.bubble, background: r.from==='admin'?'linear-gradient(135deg,#4f8ef7,#7c3aed)':'var(--surface3)', color:'white', border: r.from!=='admin'?'1px solid var(--border)':undefined }}>
                        {r.text}
                        <div style={{ fontSize:'10px', opacity:0.6, marginTop:'4px', fontFamily:'var(--mono)' }}>{new Date(r.sentAt).toLocaleString()}</div>
                      </div>
                    </div>
                  ))}
                  {m.replies?.some(r=>r.from==='admin') && (
                    <div style={{ alignSelf:'flex-start', background:'rgba(16,185,129,0.08)', border:'1px solid rgba(16,185,129,0.2)', borderRadius:'6px', padding:'5px 10px', fontSize:'11px', color:'var(--success)', fontFamily:'var(--mono)' }}>📧 Email sent to you</div>
                  )}
                </div>
              ))}
            </div>
            <div style={s.replyBox}>
              <textarea style={s.replyInput} placeholder="Message admin (private)..." value={msgText} onChange={e => setMsgText(e.target.value)} rows={1} onKeyDown={e=>e.key==='Enter'&&!e.shiftKey&&(e.preventDefault(),sendToAdmin())} />
              <button style={s.iconBtn} onClick={sendToAdmin} disabled={sending}>➤</button>
            </div>
          </>
        )}

        {/* My Messages */}
        {activePanel === 'my-messages' && (
          <>
            <div style={s.sectionHead}><span>Messages I've sent to Admin</span></div>
            <div style={s.msgList}>
              {myMessages.map(m => (
                <div key={m.id} style={s.msgCard}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'8px' }}>
                    <span style={{ fontSize:'12px', color:'var(--text3)', fontFamily:'var(--mono)' }}>To: Admin</span>
                    <span style={{ fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{new Date(m.sentAt).toLocaleString()}</span>
                  </div>
                  <div style={{ fontSize:'13px', color:'var(--text2)' }}>{m.message}</div>
                  {m.replies?.length > 0 && <div style={{ fontSize:'12px', color:'var(--success)', marginTop:'8px' }}>✅ Admin replied ({m.replies.length})</div>}
                </div>
              ))}
              {myMessages.length === 0 && <div style={{ textAlign:'center', color:'var(--text3)', padding:'40px', fontSize:'13px' }}>No messages sent yet.</div>}
            </div>
          </>
        )}
      </div>

      {/* Toast */}
      {toast && (
        <div style={{ position:'fixed', top:'20px', right:'20px', background:'var(--surface2)', border:'1px solid var(--border)', borderLeft:'3px solid var(--success)', borderRadius:'8px', padding:'12px 16px', fontSize:'13px', maxWidth:'320px', boxShadow:'var(--shadow)', zIndex:1000 }}>
          {toast}
        </div>
      )}
    </div>
  );
}
