import { useState, useEffect } from 'react';
import { useAuth } from '../lib/auth';
import { db } from '../lib/firebase';
import { collection, addDoc, onSnapshot, query, orderBy, doc, updateDoc, getDocs, getDoc } from 'firebase/firestore';

const s = {
  layout: { display:'flex', height:'100vh', overflow:'hidden', background:'var(--bg)' },
  sidebar: { width:'240px', background:'var(--surface)', borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', flexShrink:0 },
  main: { flex:1, display:'flex', flexDirection:'column', overflow:'hidden' },
  logo: { padding:'18px 16px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:'10px' },
  logoIcon: { width:'36px', height:'36px', background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', borderRadius:'10px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px' },
  navSection: { padding:'10px 8px' },
  navLabel: { fontSize:'10px', color:'var(--text3)', fontFamily:'var(--mono)', padding:'4px 10px 6px', textTransform:'uppercase', letterSpacing:'1px' },
  navItem: { display:'flex', alignItems:'center', gap:'10px', padding:'9px 10px', borderRadius:'8px', cursor:'pointer', fontSize:'13px', fontWeight:'500', color:'var(--text2)', transition:'all 0.2s', position:'relative' },
  badge: { marginLeft:'auto', background:'var(--danger)', color:'white', fontSize:'10px', fontWeight:'600', padding:'2px 7px', borderRadius:'20px', fontFamily:'var(--mono)' },
  topbar: { padding:'14px 22px', borderBottom:'1px solid var(--border)', background:'var(--surface)', display:'flex', alignItems:'center', gap:'10px' },
  dot: { width:'8px', height:'8px', borderRadius:'50%', background:'var(--success)', boxShadow:'0 0 6px var(--success)' },
  content: { flex:1, overflow:'hidden', display:'flex', flexDirection:'column' },
  statsRow: { display:'flex', gap:'10px', padding:'16px 22px 0' },
  statCard: { flex:1, background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'8px', padding:'12px 14px' },
  composeArea: { padding:'16px 22px', borderBottom:'1px solid var(--border)', background:'var(--surface)' },
  composeCard: { background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:'var(--radius)', padding:'16px' },
  groupChip: { padding:'5px 12px', borderRadius:'20px', border:'1px solid var(--border)', background:'var(--surface3)', color:'var(--text2)', fontSize:'12px', fontWeight:'500', cursor:'pointer', transition:'all 0.2s', fontFamily:'var(--font)' },
  textarea: { width:'100%', background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'8px', color:'var(--text)', fontFamily:'var(--font)', fontSize:'13px', padding:'12px', resize:'none', outline:'none', minHeight:'70px' },
  sendBtn: { padding:'9px 18px', borderRadius:'8px', background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', border:'none', color:'white', fontFamily:'var(--font)', fontSize:'13px', fontWeight:'600', cursor:'pointer' },
  msgList: { flex:1, overflowY:'auto', padding:'16px 22px', display:'flex', flexDirection:'column', gap:'10px' },
  msgCard: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--radius)', padding:'14px 16px' },
  sectionHead: { padding:'12px 22px 8px', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)', textTransform:'uppercase', letterSpacing:'1px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'space-between' },
  avatar: { width:'30px', height:'30px', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'12px', fontWeight:'700', flexShrink:0 },
  replyBox: { padding:'14px 22px', borderTop:'1px solid var(--border)', background:'var(--surface)', display:'flex', gap:'10px', alignItems:'flex-end' },
  replyInput: { flex:1, background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:'8px', color:'var(--text)', fontFamily:'var(--font)', fontSize:'13px', padding:'10px 14px', resize:'none', outline:'none', minHeight:'42px' },
  iconBtn: { width:'38px', height:'38px', borderRadius:'8px', background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', border:'none', color:'white', fontSize:'15px', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 },
  userMsgCard: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--radius)', padding:'14px 16px', cursor:'pointer', transition:'border-color 0.2s' },
  threadWrap: { flex:1, overflowY:'auto', padding:'16px 22px', display:'flex', flexDirection:'column', gap:'10px' },
  bubble: { maxWidth:'75%', padding:'10px 14px', borderRadius:'14px', fontSize:'13px', lineHeight:'1.6' },
};

const GROUPS = ['All Members', '🔵 Team Alpha', '🟢 Team Beta', '🟡 VIP Users'];

export default function AdminDashboard() {
  const { profile, logout } = useAuth();
  const [activePanel, setActivePanel] = useState('broadcast');
  const [broadcasts, setBroadcasts] = useState([]);
  const [userMsgs, setUserMsgs] = useState([]);
  const [selectedGroups, setSelectedGroups] = useState(['All Members']);
  const [msgText, setMsgText] = useState('');
  const [sending, setSending] = useState(false);
  const [toast, setToast] = useState(null);
  const [activeThread, setActiveThread] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [users, setUsers] = useState([]);

  const showToast = (msg, type='success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 4000);
  };

  useEffect(() => {
    const q = query(collection(db, 'broadcasts'), orderBy('sentAt', 'desc'));
    const unsub = onSnapshot(q, snap => setBroadcasts(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
    return unsub;
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'userMessages'), orderBy('sentAt', 'desc'));
    const unsub = onSnapshot(q, snap => setUserMsgs(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
    return unsub;
  }, []);

  useEffect(() => {
    getDocs(collection(db, 'users')).then(snap => setUsers(snap.docs.map(d => d.data())));
  }, []);

  const toggleGroup = (g) => {
    if (g === 'All Members') { setSelectedGroups(['All Members']); return; }
    const without = selectedGroups.filter(x => x !== 'All Members' && x !== g);
    setSelectedGroups(selectedGroups.includes(g) ? (without.length ? without : ['All Members']) : [...without, g]);
  };

  const sendBroadcast = async () => {
    if (!msgText.trim()) { showToast('⚠️ Write a message first', 'warn'); return; }
    setSending(true);
    try {
      const res = await fetch('/api/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msgText, targets: selectedGroups, senderEmail: profile.email }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`📡 Broadcast sent! 📧 ${data.emailsSent} email(s) delivered.`);
        setMsgText('');
      } else {
        showToast('❌ ' + data.error, 'error');
      }
    } catch (e) {
      showToast('❌ ' + e.message, 'error');
    }
    setSending(false);
  };

  const openThread = async (msg) => {
    await updateDoc(doc(db, 'userMessages', msg.id), { readByAdmin: true });
    setActiveThread(msg);
    setActivePanel('thread');
  };

  const sendReply = async () => {
    if (!replyText.trim() || !activeThread) return;
    const now = new Date().toISOString();
    // Save reply to Firestore
    await updateDoc(doc(db, 'userMessages', activeThread.id), {
      replies: [...(activeThread.replies || []), { from: 'admin', text: replyText, sentAt: now }]
    });
    // Email the user
    await fetch('/api/notify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'admin_to_user', toEmail: activeThread.fromEmail, toName: activeThread.fromName, replyMessage: replyText }),
    });
    showToast(`📧 Reply sent to ${activeThread.fromName}!`);
    setReplyText('');
    // Refresh thread
    const snap = await getDoc(doc(db, 'userMessages', activeThread.id));
    setActiveThread({ id: snap.id, ...snap.data() });
  };

  const unreadCount = userMsgs.filter(m => !m.readByAdmin).length;
  const navItems = [
    { id: 'broadcast', icon: '📢', label: 'Broadcast' },
    { id: 'user-messages', icon: '💬', label: 'User Messages', badge: unreadCount },
    { id: 'sent', icon: '📨', label: 'Sent' },
    { id: 'members', icon: '👥', label: 'Members' },
  ];

  const panelTitle = { broadcast: 'Broadcast', 'user-messages': 'User Messages', sent: 'Sent Messages', members: 'Members', thread: 'Thread' };

  return (
    <div style={s.layout}>
      {/* Sidebar */}
      <div style={s.sidebar}>
        <div style={s.logo}>
          <div style={s.logoIcon}>📡</div>
          <div>
            <div style={{ fontSize:'14px', fontWeight:'700' }}>BroadcastHub</div>
            <div style={{ fontSize:'10px', color:'var(--text3)', fontFamily:'var(--mono)' }}>Admin Console</div>
          </div>
        </div>
        <div style={s.navSection}>
          {navItems.map(n => (
            <div key={n.id} style={{ ...s.navItem, ...(activePanel===n.id||activePanel==='thread'&&n.id==='user-messages'?{background:'var(--surface3)',color:'var(--accent)'}:{}) }}
              onClick={() => { setActivePanel(n.id); if(n.id!=='user-messages') setActiveThread(null); }}>
              <span>{n.icon}</span> {n.label}
              {n.badge > 0 && <span style={s.badge}>{n.badge}</span>}
            </div>
          ))}
        </div>
        <div style={{ marginTop:'auto', padding:'14px 12px', borderTop:'1px solid var(--border)' }}>
          <div style={{ fontSize:'12px', color:'var(--text2)', marginBottom:'4px' }}>Signed in as</div>
          <div style={{ fontSize:'13px', fontWeight:'500', marginBottom:'10px', wordBreak:'break-all' }}>{profile.email}</div>
          <button onClick={logout} style={{ width:'100%', padding:'8px', borderRadius:'8px', background:'var(--surface2)', border:'1px solid var(--border)', color:'var(--text2)', fontSize:'12px', cursor:'pointer' }}>Sign Out</button>
        </div>
      </div>

      {/* Main */}
      <div style={s.main}>
        <div style={s.topbar}>
          <div style={s.dot} />
          <div style={{ fontSize:'15px', fontWeight:'600' }}>{panelTitle[activePanel]}</div>
          <div style={{ marginLeft:'auto', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>
            {broadcasts.length} broadcasts · {users.length} members
          </div>
        </div>

        {/* Broadcast Panel */}
        {activePanel === 'broadcast' && (
          <div style={s.content}>
            <div style={s.statsRow}>
              <div style={s.statCard}><div style={{ fontSize:'22px', fontWeight:'700', color:'var(--accent)', fontFamily:'var(--mono)' }}>{users.length}</div><div style={{ fontSize:'11px', color:'var(--text2)', marginTop:'2px' }}>Total Members</div></div>
              <div style={s.statCard}><div style={{ fontSize:'22px', fontWeight:'700', color:'var(--success)', fontFamily:'var(--mono)' }}>{broadcasts.length}</div><div style={{ fontSize:'11px', color:'var(--text2)', marginTop:'2px' }}>Total Broadcasts</div></div>
              <div style={s.statCard}><div style={{ fontSize:'22px', fontWeight:'700', color:'var(--warn)', fontFamily:'var(--mono)' }}>{userMsgs.length}</div><div style={{ fontSize:'11px', color:'var(--text2)', marginTop:'2px' }}>User Messages</div></div>
            </div>
            <div style={s.composeArea}>
              <div style={s.composeCard}>
                <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'12px' }}>
                  <span>📡</span><span style={{ fontSize:'14px', fontWeight:'600' }}>New Broadcast</span>
                </div>
                <div style={{ fontSize:'11px', color:'var(--text3)', marginBottom:'6px', fontFamily:'var(--mono)' }}>TARGET GROUPS</div>
                <div style={{ display:'flex', gap:'6px', flexWrap:'wrap', marginBottom:'12px' }}>
                  {GROUPS.map(g => (
                    <button key={g} style={{ ...s.groupChip, ...(selectedGroups.includes(g)?{borderColor:'var(--accent)',color:'var(--accent)',background:'rgba(79,142,247,0.1)'}:{}) }} onClick={() => toggleGroup(g)}>{g}</button>
                  ))}
                </div>
                <textarea style={s.textarea} placeholder="Write your broadcast message... (emails sent automatically)" value={msgText} onChange={e => setMsgText(e.target.value)} rows={3} />
                <div style={{ display:'flex', alignItems:'center', marginTop:'10px', gap:'10px' }}>
                  <span style={{ fontSize:'12px', color:'var(--success)' }}>📧 Email notifications ON</span>
                  <span style={{ marginLeft:'auto', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{msgText.length}/500</span>
                  <button style={s.sendBtn} onClick={sendBroadcast} disabled={sending}>{sending ? '⏳...' : '📡 Broadcast'}</button>
                </div>
              </div>
            </div>
            <div style={s.sectionHead}><span>Recent Broadcasts</span></div>
            <div style={s.msgList}>
              {broadcasts.map(b => (
                <div key={b.id} style={s.msgCard}>
                  <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'8px' }}>
                    <div style={{ ...s.avatar, background:'linear-gradient(135deg,#4f8ef7,#7c3aed)' }}>A</div>
                    <div style={{ fontSize:'13px', fontWeight:'600' }}>Admin</div>
                    <div style={{ marginLeft:'auto', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{new Date(b.sentAt).toLocaleString()}</div>
                  </div>
                  <div style={{ fontSize:'13px', color:'var(--text2)', lineHeight:'1.6' }}>{b.message}</div>
                  <div style={{ display:'flex', gap:'6px', marginTop:'8px', flexWrap:'wrap' }}>
                    {b.targets?.map(t => <span key={t} style={{ padding:'3px 9px', borderRadius:'12px', background:'rgba(79,142,247,0.1)', border:'1px solid rgba(79,142,247,0.2)', color:'var(--accent)', fontSize:'11px', fontFamily:'var(--mono)' }}>📌 {t}</span>)}
                    <span style={{ padding:'3px 9px', borderRadius:'12px', background:'rgba(16,185,129,0.1)', border:'1px solid rgba(16,185,129,0.2)', color:'var(--success)', fontSize:'11px', fontFamily:'var(--mono)' }}>📧 Emailed</span>
                  </div>
                </div>
              ))}
              {broadcasts.length === 0 && <div style={{ textAlign:'center', color:'var(--text3)', padding:'40px', fontSize:'13px' }}>No broadcasts yet. Send your first!</div>}
            </div>
          </div>
        )}

        {/* User Messages Panel */}
        {activePanel === 'user-messages' && !activeThread && (
          <div style={s.content}>
            <div style={s.sectionHead}><span>Messages from Users</span><span style={{ fontSize:'11px', color:'var(--success)', fontFamily:'var(--mono)' }}>📧 Replies trigger email</span></div>
            <div style={s.msgList}>
              {userMsgs.map(m => (
                <div key={m.id} style={{ ...s.userMsgCard, ...(m.readByAdmin?{}:{borderLeft:'3px solid var(--accent2)'}) }} onClick={() => openThread(m)}>
                  <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'8px' }}>
                    <div style={{ ...s.avatar, background:'var(--surface3)', border:'1px solid var(--border)' }}>{(m.fromName||'?')[0].toUpperCase()}</div>
                    <div>
                      <div style={{ fontSize:'13px', fontWeight:'600' }}>{m.fromName}</div>
                      <div style={{ fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{m.fromEmail}</div>
                    </div>
                    <div style={{ marginLeft:'auto', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{new Date(m.sentAt).toLocaleString()}</div>
                  </div>
                  <div style={{ fontSize:'13px', color:'var(--text2)' }}>{m.message}</div>
                  {m.replies?.length > 0 && <div style={{ fontSize:'11px', color:'var(--text3)', marginTop:'6px' }}>💬 {m.replies.length} repl{m.replies.length>1?'ies':'y'}</div>}
                </div>
              ))}
              {userMsgs.length === 0 && <div style={{ textAlign:'center', color:'var(--text3)', padding:'40px', fontSize:'13px' }}>No user messages yet.</div>}
            </div>
          </div>
        )}

        {/* Thread view */}
        {activePanel === 'thread' && activeThread && (
          <div style={s.content}>
            <div style={{ ...s.sectionHead, cursor:'pointer' }} onClick={() => { setActivePanel('user-messages'); setActiveThread(null); }}>← Back to Messages</div>
            <div style={{ padding:'12px 22px', background:'var(--surface2)', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:'10px' }}>
              <div style={{ ...s.avatar, background:'var(--surface3)', border:'1px solid var(--border)', width:'36px', height:'36px' }}>{(activeThread.fromName||'?')[0].toUpperCase()}</div>
              <div>
                <div style={{ fontSize:'14px', fontWeight:'600' }}>{activeThread.fromName}</div>
                <div style={{ fontSize:'12px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{activeThread.fromEmail}</div>
              </div>
            </div>
            <div style={s.threadWrap}>
              <div style={{ display:'flex', justifyContent:'flex-start' }}>
                <div style={{ ...s.bubble, background:'var(--surface3)', border:'1px solid var(--border)' }}>
                  {activeThread.message}
                  <div style={{ fontSize:'10px', color:'var(--text3)', marginTop:'4px', fontFamily:'var(--mono)' }}>{new Date(activeThread.sentAt).toLocaleString()}</div>
                </div>
              </div>
              {activeThread.replies?.map((r, i) => (
                <div key={i} style={{ display:'flex', justifyContent: r.from==='admin'?'flex-end':'flex-start' }}>
                  <div style={{ ...s.bubble, background: r.from==='admin'?'linear-gradient(135deg,#4f8ef7,#7c3aed)':'var(--surface3)', color:'white', border: r.from!=='admin'?'1px solid var(--border)':undefined }}>
                    {r.text}
                    <div style={{ fontSize:'10px', opacity:0.6, marginTop:'4px', fontFamily:'var(--mono)' }}>{new Date(r.sentAt).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={s.replyBox}>
              <textarea style={s.replyInput} placeholder={`Reply to ${activeThread.fromName}... (email notification sent)`} value={replyText} onChange={e => setReplyText(e.target.value)} rows={1} />
              <button style={s.iconBtn} onClick={sendReply}>➤</button>
            </div>
          </div>
        )}

        {/* Sent Panel */}
        {activePanel === 'sent' && (
          <div style={s.content}>
            <div style={s.sectionHead}><span>All Sent Broadcasts</span></div>
            <div style={s.msgList}>
              {broadcasts.map(b => (
                <div key={b.id} style={s.msgCard}>
                  <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'8px' }}>
                    <div style={{ ...s.avatar, background:'linear-gradient(135deg,#4f8ef7,#7c3aed)' }}>A</div>
                    <span style={{ fontSize:'13px', fontWeight:'600' }}>Admin</span>
                    <span style={{ marginLeft:'auto', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{new Date(b.sentAt).toLocaleString()}</span>
                  </div>
                  <div style={{ fontSize:'13px', color:'var(--text2)' }}>{b.message}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Members Panel */}
        {activePanel === 'members' && (
          <div style={s.content}>
            <div style={s.sectionHead}><span>All Members ({users.length})</span></div>
            <div style={s.msgList}>
              {users.map(u => (
                <div key={u.uid} style={s.msgCard}>
                  <div style={{ display:'flex', alignItems:'center', gap:'10px' }}>
                    <div style={{ ...s.avatar, background:'var(--surface3)', border:'1px solid var(--border)', width:'36px', height:'36px' }}>{(u.name||u.email||'?')[0].toUpperCase()}</div>
                    <div>
                      <div style={{ fontSize:'13px', fontWeight:'600' }}>{u.name}</div>
                      <div style={{ fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>{u.email}</div>
                    </div>
                    <div style={{ marginLeft:'auto', fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)' }}>Joined {new Date(u.createdAt).toLocaleDateString()}</div>
                  </div>
                </div>
              ))}
              {users.length === 0 && <div style={{ textAlign:'center', color:'var(--text3)', padding:'40px', fontSize:'13px' }}>No members yet.</div>}
            </div>
          </div>
        )}
      </div>

      {/* Toast */}
      {toast && (
        <div style={{ position:'fixed', top:'20px', right:'20px', background:'var(--surface2)', border:'1px solid var(--border)', borderLeft:'3px solid var(--success)', borderRadius:'8px', padding:'12px 16px', fontSize:'13px', maxWidth:'320px', boxShadow:'var(--shadow)', zIndex:1000 }}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
