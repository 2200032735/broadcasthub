import { Resend } from 'resend';
import { initializeApp, getApps, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

// Initialize Firebase Admin
if (!getApps().length) {
  initializeApp({
    credential: cert({
      projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    }),
  });
}

const resend = new Resend(process.env.RESEND_API_KEY);
const db = getFirestore();

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { message, targets, senderEmail } = req.body;

  if (senderEmail !== process.env.NEXT_PUBLIC_ADMIN_EMAIL) {
    return res.status(403).json({ error: 'Only admin can broadcast.' });
  }

  try {
    // Save broadcast to Firestore
    const broadcastRef = await db.collection('broadcasts').add({
      message,
      targets,
      sentAt: new Date().toISOString(),
      from: 'Admin',
    });

    // Get target users
    let usersQuery = db.collection('users');
    const usersSnap = await usersQuery.get();
    const users = usersSnap.docs.map(d => d.data());

    // Filter by groups if not "All Members"
    const targetUsers = targets.includes('All Members')
      ? users
      : users.filter(u => u.groups && u.groups.some(g => targets.includes(g)));

    // Add to each user's inbox in Firestore
    for (const u of targetUsers) {
      await db.collection('users').doc(u.uid).collection('inbox').add({
        broadcastId: broadcastRef.id,
        message,
        from: 'Admin',
        sentAt: new Date().toISOString(),
        read: false,
      });
    }

    // Send emails via Resend
    const emailResults = [];
    for (const u of targetUsers) {
      if (!u.email) continue;
      try {
        await resend.emails.send({
          from: process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev',
          to: u.email,
          subject: '📡 New message from Admin — BroadcastHub',
          html: `
            <div style="font-family:sans-serif;max-width:520px;margin:0 auto;background:#0a0d14;color:#e8eaf0;padding:32px;border-radius:16px">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:24px">
                <div style="width:40px;height:40px;background:linear-gradient(135deg,#4f8ef7,#7c3aed);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px">📡</div>
                <div>
                  <div style="font-size:18px;font-weight:700">BroadcastHub</div>
                  <div style="font-size:12px;color:#8892a4">New admin message</div>
                </div>
              </div>
              <div style="background:#171d2e;border:1px solid #2a3352;border-radius:12px;padding:20px;margin-bottom:20px">
                <div style="font-size:12px;color:#4f8ef7;margin-bottom:8px;text-transform:uppercase;letter-spacing:1px">MESSAGE FROM ADMIN</div>
                <div style="font-size:15px;line-height:1.7;color:#e8eaf0">${message}</div>
              </div>
              <div style="font-size:12px;color:#4a5568;text-align:center">
                Hi ${u.name || u.email}, you received this because you're a member of BroadcastHub.<br/>
                <a href="${process.env.NEXTAUTH_URL || 'https://your-app.vercel.app'}/dashboard" style="color:#4f8ef7">Open App →</a>
              </div>
            </div>
          `,
        });
        emailResults.push({ email: u.email, sent: true });
      } catch (e) {
        emailResults.push({ email: u.email, sent: false, error: e.message });
      }
    }

    return res.status(200).json({
      success: true,
      broadcastId: broadcastRef.id,
      emailsSent: emailResults.filter(r => r.sent).length,
      totalTargeted: targetUsers.length,
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e.message });
  }
}
