import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { message, fromName, fromEmail, type } = req.body;
  // type: 'user_to_admin' or 'admin_to_user'

  try {
    if (type === 'admin_to_user') {
      // Admin replied to user — email the user
      const { toEmail, toName, replyMessage } = req.body;
      await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev',
        to: toEmail,
        subject: '💬 Admin replied to your message — BroadcastHub',
        html: `
          <div style="font-family:sans-serif;max-width:520px;margin:0 auto;background:#0a0d14;color:#e8eaf0;padding:32px;border-radius:16px">
            <div style="margin-bottom:20px">
              <div style="font-size:18px;font-weight:700">📡 BroadcastHub</div>
              <div style="font-size:12px;color:#8892a4">Admin has replied to your message</div>
            </div>
            <div style="background:#171d2e;border:1px solid #2a3352;border-left:3px solid #4f8ef7;border-radius:12px;padding:20px;margin-bottom:16px">
              <div style="font-size:11px;color:#4f8ef7;margin-bottom:6px">ADMIN REPLIED</div>
              <div style="font-size:15px;line-height:1.7">${replyMessage}</div>
            </div>
            <a href="${process.env.NEXTAUTH_URL || 'https://your-app.vercel.app'}/dashboard" 
               style="display:inline-block;background:linear-gradient(135deg,#4f8ef7,#7c3aed);color:white;padding:10px 20px;border-radius:8px;font-size:13px;text-decoration:none">
              Open App to Reply →
            </a>
          </div>
        `,
      });
      return res.status(200).json({ success: true });
    }

    if (type === 'user_to_admin') {
      // Notify admin by email that a user messaged them
      const adminEmail = process.env.NEXT_PUBLIC_ADMIN_EMAIL;
      await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev',
        to: adminEmail,
        subject: `💬 New message from ${fromName} — BroadcastHub`,
        html: `
          <div style="font-family:sans-serif;max-width:520px;margin:0 auto;background:#0a0d14;color:#e8eaf0;padding:32px;border-radius:16px">
            <div style="margin-bottom:20px">
              <div style="font-size:18px;font-weight:700">📡 BroadcastHub</div>
              <div style="font-size:12px;color:#8892a4">New user message</div>
            </div>
            <div style="background:#171d2e;border:1px solid #2a3352;border-left:3px solid #7c3aed;border-radius:12px;padding:20px;margin-bottom:16px">
              <div style="font-size:11px;color:#7c3aed;margin-bottom:6px">FROM: ${fromName} (${fromEmail})</div>
              <div style="font-size:15px;line-height:1.7">${message}</div>
            </div>
            <a href="${process.env.NEXTAUTH_URL || 'https://your-app.vercel.app'}/dashboard"
               style="display:inline-block;background:linear-gradient(135deg,#4f8ef7,#7c3aed);color:white;padding:10px 20px;border-radius:8px;font-size:13px;text-decoration:none">
              Reply in App →
            </a>
          </div>
        `,
      });
      return res.status(200).json({ success: true });
    }

    return res.status(400).json({ error: 'Invalid type' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e.message });
  }
}
