import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../lib/auth';
import AdminDashboard from '../components/AdminDashboard';
import UserDashboard from '../components/UserDashboard';

export default function Dashboard() {
  const { user, profile, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.push('/');
  }, [user, loading]);

  if (loading || !profile) {
    return (
      <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--bg)', color:'var(--text2)', fontFamily:'var(--mono)', fontSize:'13px' }}>
        ⏳ Loading BroadcastHub...
      </div>
    );
  }

  return profile.isAdmin ? <AdminDashboard /> : <UserDashboard />;
}
