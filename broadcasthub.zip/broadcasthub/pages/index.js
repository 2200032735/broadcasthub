import { useState } from 'react';
import { useAuth } from '../lib/auth';
import { useRouter } from 'next/router';

const s = {
  wrap: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--bg)', padding:'20px' },
  card: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--radius)', padding:'36px', width:'100%', maxWidth:'420px' },
  logo: { display:'flex', alignItems:'center', gap:'12px', marginBottom:'28px', justifyContent:'center' },
  logoIcon: { width:'44px', height:'44px', borderRadius:'12px', background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'20px' },
  logoText: { fontSize:'20px', fontWeight:'700', letterSpacing:'-0.5px' },
  tabs: { display:'flex', background:'var(--surface2)', borderRadius:'var(--radius-sm)', padding:'4px', marginBottom:'24px', gap:'4px' },
  tab: { flex:1, padding:'8px', border:'none', background:'transparent', color:'var(--text2)', fontSize:'13px', fontWeight:'500', borderRadius:'6px', cursor:'pointer', transition:'all 0.2s' },
  tabActive: { background:'var(--accent)', color:'white' },
  label: { fontSize:'12px', color:'var(--text2)', marginBottom:'6px', display:'block', fontFamily:'var(--mono)' },
  input: { width:'100%', background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:'var(--radius-sm)', color:'var(--text)', padding:'11px 14px', fontSize:'13px', outline:'none', marginBottom:'14px', transition:'border-color 0.2s' },
  btn: { width:'100%', padding:'12px', borderRadius:'var(--radius-sm)', background:'linear-gradient(135deg,#4f8ef7,#7c3aed)', border:'none', color:'white', fontSize:'14px', fontWeight:'600', cursor:'pointer', marginTop:'4px' },
  err: { background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.2)', borderRadius:'var(--radius-sm)', padding:'10px 14px', fontSize:'12px', color:'var(--danger)', marginBottom:'14px' },
  hint: { fontSize:'12px', color:'var(--text3)', textAlign:'center', marginTop:'16px', fontFamily:'var(--mono)' },
};

export default function LoginPage() {
  const [tab, setTab] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const router = useRouter();

  const handle = async () => {
    setError(''); setLoading(true);
    try {
      if (tab === 'login') {
        await login(email, password);
      } else {
        if (!name.trim()) { setError('Please enter your name.'); setLoading(false); return; }
        await register(email, password, name);
      }
      router.push('/dashboard');
    } catch (e) {
      setError(e.message.replace('Firebase: ', '').replace(/\(auth.*\)/, ''));
    }
    setLoading(false);
  };

  return (
    <div style={s.wrap}>
      <div style={s.card}>
        <div style={s.logo}>
          <div style={s.logoIcon}>📡</div>
          <div>
            <div style={s.logoText}>BroadcastHub</div>
            <div style={{fontSize:'11px', color:'var(--text3)', fontFamily:'var(--mono)'}}>Controlled messaging platform</div>
          </div>
        </div>

        <div style={s.tabs}>
          <button style={{...s.tab, ...(tab==='login'?s.tabActive:{})}} onClick={()=>setTab('login')}>Sign In</button>
          <button style={{...s.tab, ...(tab==='register'?s.tabActive:{})}} onClick={()=>setTab('register')}>Register</button>
        </div>

        {error && <div style={s.err}>⚠️ {error}</div>}

        {tab === 'register' && (
          <>
            <label style={s.label}>FULL NAME</label>
            <input style={s.input} placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
          </>
        )}

        <label style={s.label}>EMAIL</label>
        <input style={s.input} type="email" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)} onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />

        <label style={s.label}>PASSWORD</label>
        <input style={s.input} type="password" placeholder="••••••••" value={password} onChange={e=>setPassword(e.target.value)} onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} onKeyDown={e=>e.key==='Enter'&&handle()} />

        <button style={s.btn} onClick={handle} disabled={loading}>
          {loading ? '⏳ Please wait...' : tab==='login' ? '🔐 Sign In' : '🚀 Create Account'}
        </button>

        <div style={s.hint}>
          {tab==='login' ? 'Admin? Sign in with your admin email.' : 'Members can only receive broadcasts & message admin.'}
        </div>
      </div>
    </div>
  );
}
