import '../styles/globals.css';
import Head from 'next/head';
import { AuthProvider } from '../lib/auth';

export default function App({ Component, pageProps }) {
  return (
    <AuthProvider>
      <Head>
        <title>BroadcastHub</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
      </Head>
      <Component {...pageProps} />
    </AuthProvider>
  );
}
